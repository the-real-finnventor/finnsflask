# finnsflask

This is a recreation of the popular python package, Flask.

## Install requirements

To install all the requirements for this project, run:

```
pip install -r requirements.txt
```
